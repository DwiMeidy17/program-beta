<div class="artikel-kop">
    <h2><b>ERROR 404: tidak ditemukan</b></h2>
</div>
<div class="artikel-isi">
    <div class="alert alert-warning">
        <p>Halaman yang anda akses tidak ditemukan pada server ini. Silahkan menuju ke halaman yang lain atau kontak admin melalui email: <code>ardianta_pargo@yahoo.co.id</code> Terima kasih!</p>
    </div>
</div>

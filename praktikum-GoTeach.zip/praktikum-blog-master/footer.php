<div class="container wrap">
    <div class="row">
        <div class="col-md-6">
            <h4><b>Kontak Saya</b></h4>
            <p>Jl. Ismail Marzuki No. 02 Mataram</p>
            <p>Telepon, WA: <tel>087866866694</tel>,<br> Email: <b>ardianta_pargo@yahoo.co.id</b></p>
            <br><br>
        </div>
        <div class="col-md-6">
            <h4><b>Twitter @ArdiantaPargo</b></h4>
            <div>
                <p class="fa fa-lg fa-twitter" style="float: left; margin: 5px 10px"></p> <p>Sedang belajar membuat blog dengan #php dan #mysql. Ternyata mudah sekali!</p>

                <p class="fa fa-lg fa-twitter" style="float: left; margin: 5px 10px"></p> <p>PHP-in Laptop sampai Hang!</p>

                <p class="fa fa-lg fa-twitter" style="float: left; margin: 5px 10px"></p> <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt.</p>
            </div>
        </div>
    </div>

    <div class="row">
        <div class="col-md-12">
            <hr>
            <p>Hak Cipta &copy; <?php  echo Date("Y"); ?> Programmer PHP</p>
        </div>
    </div>
</div>

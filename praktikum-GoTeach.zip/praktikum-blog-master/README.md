# praktikum-blog
Praktikum membuat blog sederhana dengan PHP dan MySQL

# Tampilan
## Halaman depan

![Halaman depan](http://41.media.tumblr.com/7df5eb55db3a50b8026b05f3708b7e42/tumblr_nz2w8waNxw1r0ybrro1_1280.png)

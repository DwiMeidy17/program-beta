<div class="container wrap">
    <div class="row">
        <div class="col-md-12">

            <ol class="nav navbar-nav">
                <li><a href="index.php">Home</a></li>
                <li><a href="daftar_isi.php">Daftar isi</a></li>
                <li><a href="about.php">About</a></li>
            </ol>

            <ol class="nav navbar-nav navbar-right">
                <li><a href="http://facebook.com/ardianta.pargo" target="blank"><i class="fa fa-lg fa-facebook-square"></i></a></li>
                <li><a href="http://twitter.com/ArdiantaPargo" target="blank"><i class="fa fa-lg fa-twitter-square"></i></a></li>
                <li><a href="http://github.com/ardianta" target="blank"><i class="fa fa-lg fa-github-square"></i></a></li>
            </ol>

        </div>
    </div>
</div>

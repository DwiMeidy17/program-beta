# curd-pertanian
Kode CRUD dalam satu file PHP
